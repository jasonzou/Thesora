tinyMCE.addI18n('en.example',{
	desc : 'This is just a template button'
});
